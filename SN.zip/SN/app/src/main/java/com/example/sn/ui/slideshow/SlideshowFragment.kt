package com.example.sn.ui.slideshow

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.sn.R
import com.example.sn.databinding.FragmentSlideshowBinding
import com.example.sn.ui.scanner.GalleryFragment
import com.example.sn.ui.scanner.HomeFragment

class SlideshowFragment : Fragment() {

    private var _binding: FragmentSlideshowBinding? = null
    private val binding get() = _binding!!

    companion object {
        private const val REQUEST_RECORD_AUDIO_PERMISSION = 200
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val slideshowViewModel = ViewModelProvider(this).get(SlideshowViewModel::class.java)

        _binding = FragmentSlideshowBinding.inflate(inflater, container, false)
        val root: View = binding.root




        // Set up buttons
        binding.btnMap.setOnClickListener {
            val url = "https://app.mappedin.com/map/66db474b3c92f0000b6e59e9?floor=m_e05677566f04df5b"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
        binding.btnVoice.setOnClickListener{
            startVoiceRecognition()
        }



        return root
    }

    /**
     * Check for microphone permissions before starting voice recognition.
     */
    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO_PERMISSION
            )
        } else {
            startVoiceRecognition()
        }
    }

    /**
     * Handle permissions result.
     */
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVoiceRecognition()
            } else {
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Start Google Speech-to-Text
     */
    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
        startActivityForResult(intent, REQUEST_RECORD_AUDIO_PERMISSION)
    }

    /**
     * Handle voice recognition results.
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION && resultCode == Activity.RESULT_OK) {

            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (result != null && result.isNotEmpty()) {
                handleVoiceCommand(result[0])
            }
        }
    }

    /**
     * Process voice command.
     */
    private fun handleVoiceCommand(command: String) {
        when {
            command.contains("scanner", ignoreCase = true) -> {
                parentFragmentManager.beginTransaction()
                    .replace(R.id.nav_host_fragment_content_main, HomeFragment()) // Use correct ID from your activity XML
                    .addToBackStack(null)
                    .commit()
            }
            command.contains("map", ignoreCase = true) -> {
                val url = "https://app.mappedin.com/map/66db474b3c92f0000b6e59e9?floor=m_e05677566f04df5b"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            else -> {
                Toast.makeText(requireContext(), "Command not recognized", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
