package com.example.sn.ui.porters

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.sn.R
import com.google.firebase.firestore.FirebaseFirestore

class ScheduleFragment : Fragment() {

    private lateinit var textViewPorters: TextView
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_schedule, container, false)

        // Initialize TextView correctly after view is created
        textViewPorters = view.findViewById(R.id.textViewPorters)

        // Fetch data from Firestore
        fetchData()

        return view
    }

    private fun fetchData() {
        val stringBuilder = StringBuilder()

        // Fetch Header Row
        db.collection("Schedule").document("header")
            .get()
            .addOnSuccessListener { headerDoc ->
                if (headerDoc.exists()) {
                    val headerDeparture = headerDoc.getString("Departure") ?: "Departure"
                    val headertrainNumber = headerDoc.getString("trainNumber") ?: "trainNumber"
                    val headerplatform = headerDoc.getString("platform") ?: "platform"
                    stringBuilder.append("$headerDeparture- $headertrainNumber - $headerplatform\n")
                }

                // Fetch Data Rows
                db.collection("Schedule")
                    .get()
                    .addOnSuccessListener { documents ->
                        for (document in documents) {
                            if (document.id == "header") continue // Skip header document

                            val Departure = document.getString("Departure") ?: "Departure"
                            val trainNumber = document.getString("trainNumber") ?: "trainNumber"
                            val platform = document.getString("platform") ?: "platform"
                            stringBuilder.append("$Departure - $trainNumber- $platform\n")
                        }
                        textViewPorters.text = stringBuilder.toString()
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(
                            requireContext(),
                            "Error: ${exception.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(requireContext(), "Error: ${exception.message}", Toast.LENGTH_SHORT)
                    .show()
            }
    }
}