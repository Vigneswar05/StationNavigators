package com.example.sn.ui.porters

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.sn.R
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore

class PortersFragment : Fragment() {

    private lateinit var tableLayoutPorters: TableLayout

    //private val db = FirebaseFirestore.getInstance()
    val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_porters, container, false)
          tableLayoutPorters = view.findViewById(R.id.tableLayoutPorters)

        fetchData()

        return view
    }

    private fun fetchData() {
        tableLayoutPorters.removeAllViews()


        // Fetch Header Row
        db.collection("porters").document("header")
            .get()
            .addOnSuccessListener { headerDoc ->
                if (headerDoc.exists()) {
                    val headerName = headerDoc.getString("name") ?: "Name"
                    val headerPhone = headerDoc.getString("phone") ?: "Phone"
                    val headerCost = headerDoc.getString("cost") ?: "Cost"
                    val headerPlatform = headerDoc.getString("platform") ?: "Platform"
                    val headerRow = TableRow(requireContext())
                    headerRow.addView(createTextView(headerName))
                    headerRow.addView(createTextView(headerPhone))
                    headerRow.addView(createTextView("₹$headerCost"))
                    headerRow.addView(createTextView(headerPlatform))

                    // Add the header row to the TableLayout
                    tableLayoutPorters.addView(headerRow)
                    tableLayoutPorters.addView(createSeparator())

                }

                // Fetch Data Rows
                db.collection("porters")
                    .get()
                    .addOnSuccessListener { documents ->
                        for (document in documents) {
                            if (document.id == "header") continue // Skip header document

                            val name = document.getString("name") ?: "Unknown"
                            val phone = document.getString("phone") ?: "No Phone"
                            val cost = document.getString("cost") ?: "No Cost"
                            val platform = headerDoc.getString("platform") ?: "Cost"
                            val dataRow = TableRow(requireContext())
                            dataRow.addView(createTextView(name))
                            dataRow.addView(createTextView(phone))
                            dataRow.addView(createTextView("₹$cost"))
                            dataRow.addView(createTextView(platform))

                            // Add the data row to the TableLayout
                            tableLayoutPorters.addView(dataRow)
                            tableLayoutPorters.addView(createSeparator())

                        }

                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(requireContext(), "Error: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(requireContext(), "Error: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createTextView(text: String): TextView {
        val textView = TextView(requireContext())
        textView.text = text
        textView.setPadding(16, 16, 16, 16)  // Padding for better readability
        textView.setTypeface(null, android.graphics.Typeface.BOLD)

        // Optional: You can also adjust the text size
        textView.textSize = 16f  // Font size in SP (scaled pixels)

        textView.textAlignment = View.TEXT_ALIGNMENT_CENTER
        return textView
    }
    private fun createSeparator(): View {
        val separator = View(requireContext())
        separator.layoutParams = TableRow.LayoutParams(
            TableRow.LayoutParams.MATCH_PARENT, 2) // Height of 2dp
        separator.setBackgroundColor(Color.GRAY) // Gray line color
        return separator
    }

}
